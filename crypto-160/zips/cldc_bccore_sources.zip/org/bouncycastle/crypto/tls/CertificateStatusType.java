package org.bouncycastle.crypto.tls;

public class CertificateStatusType
{
    /*
     *  RFC 3546 3.6
     */
    public static final short ocsp = 1;
}
